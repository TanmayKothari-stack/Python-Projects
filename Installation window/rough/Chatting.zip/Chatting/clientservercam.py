import cv2
import socket

# Set up a socket connection
sock = socket.socket()
sock.connect(('localhost', 8000))

# Set up a VideoCapture object
cap = cv2.VideoCapture(sock)

# Display the video stream
while True:
    ret, frame = cap.read()
    cv2.imshow('frame', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the VideoCapture object and close the window
cap.release()
cv2.destroyAllWindows()
