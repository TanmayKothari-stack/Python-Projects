import tkinter
from tkinter import*

root = Tk()
listbox = Listbox(root,width=20,height=10,bg='ivory',fg='red')
listbox.place(x=10,y=10)
listbox.insert(0,"Dummy Data")
listbox.insert(0,"Dummy Data")
root.mainloop()