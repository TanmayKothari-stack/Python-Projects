import socket,cv2,pickle,struct

server = socket.socket()
host = socket.gethostname()
host_ip = socket.gethostbyname(host)
print('HOST IP',host_ip)
server.bind((host,8080))
server.listen(5)
print('listening at',(host,8080))

while True:
	client,addr = server.accept()
	print('GOT CONNECTION FROM: ',addr)
	if client:
		vid = cv2.VideoCapture(0)
		while(vid.isOpened()):
			img,frame = vid.read()
			a = pickle.dumps(frame)
			message = struct.pack("Q",len(a))+a
			client.sendall(message)
			cv2.imshow('TRANSMITING VIDEO',frame)
			key = cv2.waitKey(1) & 0XFF
			if key == ord('Q') or key == ord('q'):
				client.close()
