import socket
import thread

def on_new_client(clientsocket, addr):
    while True:
        msg = clientsocket.recv(1024)
        # do some checks and if msg == someWeirdSignal: break:
        print(addr, ' >> ', msg)
        msg = raw_input('SERVER >> ')
        # Maybe some code to compute the last digit of PI, play game or anything else can go here and when you are done.
        clientsocket.send(msg)
    clientsocket.close()

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = socket.gethostname()
port = 12345
print('Server started!')
print('Waiting for clients...')
s.bind((host, port))
s.listen(5)

while True:
    c, addr = s.accept()
    thread.start_new_thread(on_new_client, (c, addr))
