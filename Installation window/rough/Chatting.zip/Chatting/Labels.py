from tkinter import *

root = Tk()

# Create a list of positions
 

# Create labels and place them using pack() function

for i in range(101):
    label1 = Label(root,text=i,bg='green',fg='white',font=('verdena',12))
    label1.pack(side='top',pady=20,padx=20,anchor='w')

    label2 = Label(root,text=i,bg='green',fg='white',font=('verdena',12))
    label2.pack(side='top',pady=10,padx=10,anchor='ne')
root.mainloop()
