import mysql.connector
conn = mysql.connector.connect(host = 'localhost', user='root', password = '', db='chat_room')

import socket
import threading
import time
import tkinter
from tkinter import *

root = Tk()
cursor = conn.cursor()
global l
l = []
def recive():
	while True:
		try:
			data = client.recv(1024)
			if not data:
				break
			time.sleep(1)
			message = data.decode("utf-8")
			l.append(message)
			print(l)
			y = 0
			for i in l:
				print(i)
				y = y+30
				Label(root,text=f'{i}',fg='white',bg='green',font='verdena 12').place(x=10,y=y)
			print(f'From client: {message}\n')
		except Exception as e:
			#break
			print("Error!")
def send():
	while True:
		try:
			message = input()
			client.send(message.encode("utf-8"))
			cursor.execute("insert into chats (ip,message) values(%s,%s)",(host,message))
			if conn.commit():
				pass
			
			print(f'You: {message}\n')
		except Exception as e:
			raise e

host = 'localhost'
port = 8080

while True:
	try:
		client = socket.socket()
		client.connect((host,port))
		break
	except Exception as e:
		time.sleep(1)
recive_thread = threading.Thread(target=recive)
recive_thread.start()
send_thread = threading.Thread(target=send)
send_thread.start()
root.mainloop()