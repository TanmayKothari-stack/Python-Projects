import socket
import threading
import pyaudio


def recive():
    while True:
        try:
            data = client_socket.recv(CHUNK)
            if not data:
                break
            stream.write(data)
        except Exception as e:
            print(e)
            break


def send():
    while True:
        try:
            audio_stream = pyaudio.PyAudio()
            stream = audio_stream.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)
            data = stream.read(CHUNK)
            client_socket.sendall(data)
        except Exception as e:
            break
            print(e)
            print("Connection Is Closed")


while True:
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((socket.gethostbyname(socket.gethostname()), 5555))
        break
    except Exception as e:
        pass



FORMAT = pyaudio.paInt16
CHANNELS = 2
RATE = 48000
CHUNK = 1024
audio_stream = pyaudio.PyAudio()
stream = audio_stream.open(format=FORMAT, channels=CHANNELS, rate=RATE, output=True, frames_per_buffer=CHUNK)

recive_thread = threading.Thread(target=recive)
recive_thread.start()
send_thread = threading.Thread(target=send)
send_thread.start()