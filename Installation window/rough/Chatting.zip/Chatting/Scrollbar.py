from tkinter import *
from tkinter import ttk

root = Tk()
root.geometry('500x600')
canvas = Canvas(root)
canvas.pack(fill=BOTH,expand=1,side=LEFT)
scrollbar = ttk.Scrollbar(root,orient=VERTICAL,command=canvas.yview)
scrollbar.pack(side=LEFT,fill=BOTH)
canvas.configure(yscrollcommand=scrollbar.set)
canvas.bind('<Configure>',lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
frame = Frame(root,bg='blue',padx=300)
canvas.create_window((0,0),window=frame)

for i in range(0,101):
	label1 = Label(frame,text=i,font=('verdena',12),bg='red',fg='white')
	label1.pack(side='top',pady=10,padx=10,anchor='sw')

	Label(frame,text=i,font=('verdena',12),bg='orange',fg='white').pack(side='top',pady=10,padx=500,anchor='sw')
	
	label2 = Label(frame,text=i,font=('verdena',12),bg='green',fg='white')
	label2.pack(side='top',pady=10,padx=300,anchor='ne')
	pass

#for j in range(0,101):
	#(frame,text=j,font=('verdena',12),bg='green',fg='white',width=10).pack()
root.mainloop()