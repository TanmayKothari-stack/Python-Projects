import mysql.connector
conn = mysql.connector.connect(host = 'localhost', user='root', password = '', db='chat_room')

import socket
import threading
import time
cursor = conn.cursor()
def recive():
	while True:
		try:
			data = client.recv(1024)
			if not data:
				break
			time.sleep(1)
			message = data.decode("utf-8")
			print(f'From client: {message}\n')
		except Exception as e:
			break
			print("Error!")
def send():
	while True:
		try:
			message = input()
			client.send(message.encode("utf-8"))
			cursor.execute("insert into chats (ip,message) values(%s,%s)",(host,message))
			#if conn.commit():
			#	pass
			print(f'You: {message}\n')
		except Exception as e:
			raise e

host = 'localhost'
port = 8080

while True:
	try:
		client = socket.socket()
		client.connect((host,port))
		break
	except Exception as e:
		time.sleep(1)
recive_thread = threading.Thread(target=recive)
recive_thread.start()
send_thread = threading.Thread(target=send)
send_thread.start()