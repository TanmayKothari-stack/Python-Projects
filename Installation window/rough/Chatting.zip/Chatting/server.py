import socket
import threading
import time
def recive(client, addr):
	#import chatting.py
	print(f'Get connection from: {addr}\n')
	while True:
		try:
			if len(clients) == 1:
				print(f"The {len(clients)} client is connected to the server\n")
			else:
				print(f"The {len(clients)} Clients are connected to the server\n")

			data = client.recv(1024)
			if not data:
				break
			message = data.decode("utf-8")
			print(f'Message Recive {message} From: {addr}\n')
			broadcast(message, client)
		except Exception as e:
			print("Error!\n")
			break
	print(f"Connection is closed by {addr}\n")
	clients.remove(client)
	client.close()
def broadcast(message, sender):
	for client in clients:
		if sender!= client:
			try:
				client.send(message.encode("utf-8"))
			except Exception as e:
				print(e)

host = 'localhost'
port = 8080

server = socket.socket()
server.bind((host,port))
server.listen(5)

print("Server Started\n")
global clients
clients = []
count = 0
if clients==[]:
	#import chatting.py
	pass
while True:
	client, addr = server.accept()
	clients.append(client)
	client_thread = threading.Thread(target=recive,args=(client,addr))
	client_thread.start()