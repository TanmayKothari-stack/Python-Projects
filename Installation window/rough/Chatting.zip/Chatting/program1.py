import socket
import threading
import time
import tkinter
from tkinter import*
root=Tk()
root.geometry("500x500+400+50")

def func():
	time.sleep(0)
	t=threading.Thread(target=recv)
	t.start()
	root.destroy()
def recv():
	listensocket=socket.socket()
	port=4243
	maxconnection=99
	ip='localhost'
	#print(ip,'\n')
	listensocket.bind(('',port))
	listensocket.listen(maxconnection)
	(clientsocket,address)=listensocket.accept()

	while True:
		sendermessage=clientsocket.recv(1024).decode()
		if not sendermessage=="":
			time.sleep(1)
			print(f"\nClient: {sendermessage}\n")

xr = 0

def sendmsg():
	global xr
	if xr==0:
		s=socket.socket()
		hostname='localhost'
		port = 5050
		while True:
			try:
				s.connect((hostname,port))
				break
			except Exception as e:
				time.sleep(1)
		xr+=1
		while True:
			msg = input("Enter your message: ")
			print(f"You: {msg}\n")
			s.send(msg.encode())
	else:
		while True:
			msg=input("Enter your message: ")
			print(f"You: {msg}\n")
			s.send(msg.encode())

def threadsendmsg():
	th=threading.Thread(target=sendmsg)
	th.start()

def askquestion():
	#ask = input("Enter Yes or No: ")
	ask='yes'
	if ask=='yes':
		threadsendmsg()

#start=Button(root,bg='steelblue',fg='white',font='verdena 12',text='Start Chat',command=func)
#start.place(x=250,y=300)
#send=Button(root,bg='#f6e5f2',fg='white',font='verdena 12',text='Send Message',command=threadsendmsg)
#send.place(x=250,y=400)
#func()
#threadsendmsg()
#root.mainloop()
#if start:
func()
askquestion()
