import socket
import threading
import pyaudio

def recive(client_socket,client_address):
    while True:
        try:
            data = client_socket.recv(CHUNK)
            if not data:
                break

            #stream.write(data)
            broadcast(data,client_socket)
        except Exception as e:
            break
            print(e)
            
    clients.remove(client_socket)
    client_socket.close()
    print(f"\nConnection is closed by: {client_address}")

def broadcast(data,sender):
    for client_socket in clients:
        if sender!=client_socket:
            try:
                client_socket.sendall(data)
                pass
            except Exception as e:
                break
                raise e

FORMAT = pyaudio.paInt16
CHANNELS = 2
RATE = 48000
CHUNK = 1024

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('0.0.0.0', 5555))
server_socket.listen(True)

print("Waiting for a connection...\n")

clients = []

audio_stream = pyaudio.PyAudio()
stream = audio_stream.open(format=FORMAT, channels=CHANNELS, rate=RATE, output=True, frames_per_buffer=CHUNK)

while True:
    client_socket, client_address = server_socket.accept()
    print(f"Got Connection from: {client_address}\n")
    clients.append(client_socket)
    client_thread = threading.Thread(target=recive,args=(client_socket,client_address))
    client_thread.start()



